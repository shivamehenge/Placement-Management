package com.cg.placementmanagement.entities;

public class Student {

	private long id;
	private String name;
	private College college;
	private long roll;
	private String qualification;
	private String course;
	private int year;
	private Certificate certificate;
	private long hallTicketNo;
}
