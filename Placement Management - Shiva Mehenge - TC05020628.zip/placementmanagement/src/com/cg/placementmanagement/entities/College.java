package com.cg.placementmanagement.entities;

public class College {
private long id;
private User collegeAdmin;
private String collegeName;
private String location;
}
