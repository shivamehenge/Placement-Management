package com.cg.placementmanagement.entities;

@Entity
public class Admin 
{
	@Id
private long id;
	
private String name;
private String password;

// Getter & Setters


}
