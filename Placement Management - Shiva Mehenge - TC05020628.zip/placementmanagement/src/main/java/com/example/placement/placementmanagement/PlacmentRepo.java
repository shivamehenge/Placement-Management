package com.example.placement.placementmanagement;

import org.springframework.data.repository.CrudRepository;

public interface PlacmentRepo extends CrudRepository<placement, Integer>{

}
